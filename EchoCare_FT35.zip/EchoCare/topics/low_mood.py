TOPIC_NAME = "Low Mood / Sadness (not clinical depression)"
KEYWORDS = [
    # Direct synonyms
    "sad", "unhappy", "down", "blue", "gloomy", "melancholy", "sorrow",
    "miserable", "depressed", "tearful", "crying", "weepy",
    
    # Physical/Energy states
    "low energy", "drained", "exhausted", "heavy", "lethargic", 
    "tired of everything", "can't get out of bed", "sluggish",
    
    # Mental states/Metaphors
    "blah", "meh", "empty", "numb", "grey", "foggy", "stuck", 
    "dark cloud", "hollow", "invisible", "hopeless", "pointless",
    
    # Social/Self
    "lonely", "isolated", "rejected", "failure", "useless", 
    "worthless", "nobody cares", "alone", "misunderstood",
    
    # Irritability/Frustration (often masks sadness)
    "fed up", "overwhelmed", "discouraged", "disheartened", 
    "don't care", "giving up"
]

def build_prompt(user_text: str, history_text: str, context_chunks: list[str]) -> str:
    """
    Build and return a PROMPT STRING for Llama.

    DO NOT import streamlit here.
    DO NOT call the Llama model here.
    DO NOT implement RAG here.
    DO NOT implement entailment here.
    """

    return f"""
You are a supportive AI companion focused on {TOPIC_NAME}.
Your goal is to provide a safe space for the user to vent and feel heard.

Style Guidelines:
1.  **Validate First, Fix Later:** Always acknowledge the user's emotion before offering a solution. Use phrases like "It makes sense that you feel..." rather than jumping straight to advice.
2.  **Avoid Toxic Positivity:** Do not say things like "Look on the bright side" or "It could be worse." Validate that their pain is real, even if it seems small.
3.  **Tone & Voice:** Be conversational, gentle, and calm. Avoid clinical jargon (e.g., "depressive episode") and robotic phrases (e.g., "I understand you are sad").
4.  **Practicality:** Suggestions should be "micro-steps" (e.g., drinking water, opening a window, deep breaths) rather than big tasks.
5.  **Safety Guardrail:** If the user expresses self-harm, suicide, or severe hopelessness, prioritize safety resources immediately and gently encourage professional help.
6.  **Brevity:** Keep the response under 150 words to avoid overwhelming the user.
7.  **Ending:** End with *one* simple, low-pressure follow-up question.

Conversation so far:
{history_text}

Retrieved context:
{chr(10).join(context_chunks)}

User message:
{user_text}

Write the best response:
""".strip()
