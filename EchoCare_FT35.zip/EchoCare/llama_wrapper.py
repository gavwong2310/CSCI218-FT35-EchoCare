# llama_wrapper.py
# EchoCare: ONLY file that calls Ollama

from __future__ import annotations
from typing import List, Dict, Optional
import requests
OLLAMA_HOST = "http://localhost:11434"
DEFAULT_OPTIONS = {
    "temperature": 0.5,
    "top_p": 0.9,
    "repeat_penalty": 1.15,
    "num_ctx": 2048,
    "num_predict": 220,
}

def ollama_chat(
    prompt: str,
    history: Optional[List[Dict]] = None,
    model: str = "llama3.1",
    system: str = "",
    options: Optional[dict] = None,
    timeout: int = 60,
) -> str:
    """
    Uses Ollama /api/chat.
    - prompt: the composed prompt string (includes history/context instructions)
    - history: list of {"role": "user"/"assistant", "content": "..."}
    """

    opts = dict(DEFAULT_OPTIONS)
    if options:
        opts.update(options)

    messages = []
    if system:
        messages.append({"role": "system", "content": system})

    # Keep only last few turns to reduce repetition
    if history:
        for m in history[-6:]:
            role = m.get("role")
            content = (m.get("content") or "").strip()
            if role in ("user", "assistant") and content:
                messages.append({"role": role, "content": content})

    # Add latest prompt as the final user message
    messages.append({"role": "user", "content": prompt})

    payload = {
        "model": model,
        "messages": messages,
        "stream": False,
        "options": opts,
    }

    r = requests.post(f"{OLLAMA_HOST}/api/chat", json=payload, timeout=timeout)
    r.raise_for_status()
    data = r.json()
    return (data.get("message", {}) or {}).get("content", "").strip()

