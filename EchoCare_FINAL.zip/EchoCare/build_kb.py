from __future__ import annotations
import os
from datasets import load_dataset
import re
import numpy as np

TOPICS = [
    "anxiety",
    "stress_burnout",
    "loneliness",
    "anger_guilt",
    "insecurity_selfesteem",
    "low_mood",
]

OUTDIR = "data/kb"
os.makedirs(OUTDIR, exist_ok=True)

_ws = re.compile(r"\s+")
def clean(t: str) -> str:
    t = (t or "").strip()
    t = re.sub(r"http\S+|www\.\S+", " ", t)
    t = re.sub(r"[^a-zA-Z0-9\s'’-]", " ", t)
    t = _ws.sub(" ", t).strip()
    return t

def good(t: str) -> bool:
    return t and len(t) >= 25 and len(t.split()) >= 5

def anchors(topic: str):
    base = {
        "anxiety": [
            "I keep worrying about the future and I can't stop overthinking.",
            "My heart is racing and I feel panic and fear.",
            "Grounding 5-4-3-2-1 helps bring me back to the present.",
        ],
        "stress_burnout": [
            "My workload is too much and I feel overwhelmed by deadlines.",
            "I can't switch off after work or school and I'm exhausted.",
            "Must/Should/Could prioritisation helps reduce overload.",
        ],
        "loneliness": [
            "I feel lonely even when I'm around people.",
            "I feel left out and disconnected from my friends.",
            "One small intentional connection can help rebuild belonging.",
        ],
        "anger_guilt": [
            "I'm angry and frustrated and I struggle to calm down.",
            "I snapped at someone and now I feel guilty and regretful.",
            "STOP: Stop, Take a breath, Observe, Proceed intentionally.",
        ],
        "insecurity_selfesteem": [
            "I feel like I'm not good enough and people will judge me.",
            "I keep comparing myself to others and feel like an imposter.",
            "A thought is not a fact: I'm having the thought that…",
        ],
        "low_mood": [
            "I feel sad, empty, and numb with low energy.",
            "I feel hopeless and nothing feels enjoyable.",
            "A tiny activation step can help when motivation is low.",
        ],
    }
    return base[topic]

def sample_go(topic: str, n: int = 2000):
    ds = load_dataset("google-research-datasets/go_emotions", "simplified")
    names = ds["train"].features["labels"].feature.names
    name_to_id = {n: i for i, n in enumerate(names)}

    mapping = {
        "anxiety": {"fear", "nervousness"},
        "stress_burnout": {"nervousness", "fear"},
        "loneliness": {"sadness"},
        "anger_guilt": {"anger", "annoyance", "disgust", "remorse"},
        "insecurity_selfesteem": {"embarrassment", "confusion", "remorse", "disapproval", "disappointment"},
        "low_mood": {"sadness", "disappointment", "grief", "remorse"},
    }
    include_ids = {name_to_id[x] for x in mapping[topic] if x in name_to_id}

    out = []
    for row in ds["train"]:
        txt = clean(row.get("text", ""))
        if not good(txt):
            continue
        labs = set(row.get("labels") or [])
        if include_ids and labs.intersection(include_ids):
            out.append(txt)
        if len(out) >= n:
            break
    return out

def save(topic: str, lines: list[str]):
    p = os.path.join(OUTDIR, f"{topic}.txt")
    with open(p, "w", encoding="utf-8") as f:
        for s in lines:
            f.write(s.strip() + "\n")
    print(f"[KB] wrote {len(lines):4d} -> {p}")

def main():
    for t in TOPICS:
        lines = anchors(t) + sample_go(t, n=2200)
        # dedupe
        seen = set()
        final = []
        for s in lines:
            s2 = s.lower()
            if s2 in seen: 
                continue
            seen.add(s2)
            final.append(s)
        save(t, final[:2200])

    print("KB rebuilt successfully.")

if __name__ == "__main__":
    main()