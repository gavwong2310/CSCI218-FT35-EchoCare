# evaluate_results.py
# Run: py evaluate_results.py --log data/feedback_log.jsonl --outdir reports
from __future__ import annotations
import argparse
import csv
import json
import os
from collections import Counter
from statistics import mean, median
import matplotlib.pyplot as plt

# -------------------------
# Helpers
# -------------------------
def safe_mean(xs):
    xs = [x for x in xs if x is not None]
    return mean(xs) if xs else None

def safe_median(xs):
    xs = [x for x in xs if x is not None]
    return median(xs) if xs else None

def read_jsonl(path: str):
    rows = []
    if not os.path.exists(path):
        raise FileNotFoundError(f"Log file not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                # skip malformed lines
                continue
    return rows

def ensure_outdir(outdir: str):
    os.makedirs(outdir, exist_ok=True)

def save_fig(path: str):
    # Higher DPI for report/lecturer screenshots
    plt.tight_layout()
    plt.savefig(path, dpi=220)
    plt.close()

def plot_bar(labels, values, title, xlabel, ylabel, outpath, rotate=25):
    plt.figure(figsize=(9, 4.8))
    plt.bar(labels, values)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    if rotate:
        plt.xticks(rotation=rotate, ha="right")
    save_fig(outpath)

def plot_hist(values, title, xlabel, ylabel, outpath, bins=20):
    if not values:
        return
    plt.figure(figsize=(8.5, 4.8))
    plt.hist(values, bins=bins)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    save_fig(outpath)

def plot_donut(correct: int, total: int, title: str, outpath: str):
    wrong = max(total - correct, 0)
    sizes = [correct, wrong]
    labels = ["Correct", "Incorrect"]
    plt.figure(figsize=(5.2, 5.2))
    wedges, _ = plt.pie(sizes, labels=labels, startangle=90, wedgeprops=dict(width=0.45))
    plt.title(title)
    save_fig(outpath)

def write_turns_csv(path: str, turns: list[dict]):
    # A clean export that is easy to show in appendices
    fields = [
        "timestamp",
        "topic",
        "route_confidence",
        "rag_top1",
        "rag_empty",
        "entail_score",
        "entail_pass",
        "latency_sec",
        "user_text",
    ]
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for t in turns:
            scores = t.get("rag_scores")
            rag_top1 = None
            rag_empty = 1
            if isinstance(scores, list) and scores:
                floats = [s for s in scores if isinstance(s, (int, float))]
                if floats:
                    rag_top1 = max(floats)
                    rag_empty = 0
            w.writerow({
                "timestamp": t.get("ts") or t.get("timestamp") or "",
                "topic": t.get("topic") or "",
                "route_confidence": t.get("route_confidence") if isinstance(t.get("route_confidence"), (int, float)) else "",
                "rag_top1": rag_top1 if isinstance(rag_top1, (int, float)) else "",
                "rag_empty": rag_empty,
                "entail_score": t.get("entail_score") if isinstance(t.get("entail_score"), (int, float)) else "",
                "entail_pass": t.get("entail_pass") if isinstance(t.get("entail_pass"), bool) else "",
                "latency_sec": t.get("latency_sec") if isinstance(t.get("latency_sec"), (int, float)) else "",
                "user_text": (t.get("user_text") or "")[:300],
            })


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--log", default="data/feedback_log.jsonl", help="Path to feedback_log.jsonl")
    ap.add_argument("--outdir", default="reports", help="Where to save plots and summaries")
    ap.add_argument("--save_csv", default=None, help="Optional: save per-turn CSV to this path")
    args = ap.parse_args()

    ensure_outdir(args.outdir)
    rows = read_jsonl(args.log)

    turns = [r for r in rows if r.get("event") == "turn"]
    ratings = [r for r in rows if r.get("event") == "user_rating"]
    safety_blocks = [r for r in rows if r.get("event") == "blocked_by_safety"]

    # --- Basic counts ---
    n_turns = len(turns)
    n_ratings = len(ratings)
    n_safety = len(safety_blocks)

    # --- Topic distribution ---
    topic_counts = Counter([t.get("topic") for t in turns if t.get("topic")])

    # --- Routing confidence ---
    route_conf = [t.get("route_confidence") for t in turns if isinstance(t.get("route_confidence"), (int, float))]

    # --- RAG top1 and empty retrieval ---
    rag_top1 = []
    rag_empty = 0
    for t in turns:
        scores = t.get("rag_scores")
        if isinstance(scores, list) and scores:
            floats = [s for s in scores if isinstance(s, (int, float))]
            if floats:
                rag_top1.append(max(floats))
            else:
                rag_empty += 1
        else:
            rag_empty += 1

    # --- Entailment ---
    entail_scores = []
    entail_pass = []
    for t in turns:
        s = t.get("entail_score")
        p = t.get("entail_pass")
        if isinstance(s, (int, float)):
            entail_scores.append(float(s))
        if isinstance(p, bool):
            entail_pass.append(p)

    # --- Latency ---
    latency = [t.get("latency_sec") for t in turns if isinstance(t.get("latency_sec"), (int, float))]

    # --- User ratings ---
    rating_vals = [r.get("rating") for r in ratings if isinstance(r.get("rating"), (int, float))]

    # -------------------------
    # Print a clean console report
    # -------------------------
    print("\n" + "=" * 64)
    print("EchoCare Evaluation Report (from system logs)")
    print("=" * 64)
    print(f"Log file: {args.log}")
    print(f"Total turns: {n_turns}")
    print(f"User ratings submitted: {n_ratings}")
    print(f"Safety blocks triggered: {n_safety}")

    print("\n--- Topic Distribution ---")
    if topic_counts:
        for topic, c in topic_counts.most_common():
            pct = (c / n_turns * 100) if n_turns else 0
            print(f"{topic:28s}  {c:5d}  ({pct:5.1f}%)")
    else:
        print("No topic data found in logs.")

    print("\n--- Routing Confidence (Classical NLP routing) ---")
    if route_conf:
        print(f"Mean route_confidence:   {safe_mean(route_conf):.3f}")
        print(f"Median route_confidence: {safe_median(route_conf):.3f}")
    else:
        print("No route_confidence found.")

    print("\n--- RAG Retrieval Strength ---")
    if rag_top1:
        print(f"Mean top-1 RAG score:    {safe_mean(rag_top1):.3f}")
        print(f"Median top-1 RAG score:  {safe_median(rag_top1):.3f}")
    if n_turns:
        print(f"Empty retrieval turns:   {rag_empty} / {n_turns} ({(rag_empty/n_turns*100):.1f}%)")

    print("\n--- Entailment Gate (Anti-hallucination) ---")
    if entail_scores:
        print(f"Mean entail_score:       {safe_mean(entail_scores):.3f}")
        print(f"Median entail_score:     {safe_median(entail_scores):.3f}")
    if entail_pass:
        pass_rate = sum(1 for x in entail_pass if x) / len(entail_pass) * 100
        print(f"Entailment pass rate:    {pass_rate:.1f}%  (n={len(entail_pass)})")

    print("\n--- System Latency ---")
    if latency:
        print(f"Mean latency (sec):      {safe_mean(latency):.3f}")
        print(f"Median latency (sec):    {safe_median(latency):.3f}")

    if rating_vals:
        print("\n--- User Ratings ---")
        print(f"Mean rating:             {safe_mean(rating_vals):.2f}")
        print(f"Median rating:           {safe_median(rating_vals):.2f}")

    print("=" * 64 + "\n")

    # -------------------------
    # Lecturer-friendly plots
    # -------------------------
    # 1) Topic distribution
    if topic_counts:
        labels = list(topic_counts.keys())
        values = [topic_counts[k] for k in labels]
        plot_bar(
            labels, values,
            title="Turns by Routed Topic",
            xlabel="Topic",
            ylabel="Number of turns",
            outpath=os.path.join(args.outdir, "topics_bar.png"),
            rotate=25
        )

    # 2) Route confidence histogram
    plot_hist(
        route_conf,
        title="Routing Confidence Distribution (TF-IDF Router)",
        xlabel="route_confidence",
        ylabel="Count",
        outpath=os.path.join(args.outdir, "route_confidence_hist.png"),
        bins=16
    )

    # 3) RAG top1 histogram
    plot_hist(
        rag_top1,
        title="RAG Retrieval Strength (Top-1 Score)",
        xlabel="Top-1 similarity score",
        ylabel="Count",
        outpath=os.path.join(args.outdir, "rag_top1_hist.png"),
        bins=16
    )

    # 4) Entailment score histogram
    plot_hist(
        entail_scores,
        title="Entailment Score Distribution (Anti-hallucination gate)",
        xlabel="entail_score",
        ylabel="Count",
        outpath=os.path.join(args.outdir, "entail_score_hist.png"),
        bins=16
    )

    # 5) Latency histogram
    plot_hist(
        latency,
        title="System Latency Distribution",
        xlabel="latency_sec",
        ylabel="Count",
        outpath=os.path.join(args.outdir, "latency_hist.png"),
        bins=16
    )

    # 6) Ratings histogram
    plot_hist(
        rating_vals,
        title="User Ratings Distribution",
        xlabel="rating",
        ylabel="Count",
        outpath=os.path.join(args.outdir, "ratings_hist.png"),
        bins=10
    )

    # 7) Entailment pass donut (if available)
    if entail_pass:
        correct = sum(1 for x in entail_pass if x)
        plot_donut(
            correct=correct,
            total=len(entail_pass),
            title="Entailment Gate: Pass vs Fail",
            outpath=os.path.join(args.outdir, "entail_pass_donut.png")
        )

    # Export per-turn CSV if requested
    if args.save_csv:
        write_turns_csv(args.save_csv, turns)
        print(f"Saved per-turn CSV -> {args.save_csv}")

    print(f"Saved plots to -> {args.outdir}")


if __name__ == "__main__":
    main()