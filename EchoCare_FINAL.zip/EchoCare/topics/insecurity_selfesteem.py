from __future__ import annotations
from datasets import load_dataset
from typing import List

TOPIC_NAME = "Insecurity & Self-Doubt (Self-esteem support)"

KEYWORDS = [
    "insecurity", "self doubt", "self-esteem", "confidence",
    "imposter", "not good enough", "comparison", "validation"
]

def build_corpus(max_rows: int = 1200, min_chars: int = 35) -> list[str]:
    ds = load_dataset("google-research-datasets/go_emotions", "simplified")
    names = ds["train"].features["labels"].feature.names
    name_to_id = {n: i for i, n in enumerate(names)}

    # Insecurity/self-esteem proxies that usually exist in simplified:
    include = {
        name_to_id.get("embarrassment"),
        name_to_id.get("nervousness"),
        name_to_id.get("disappointment"),
        name_to_id.get("remorse"),
        name_to_id.get("confusion"),
        name_to_id.get("fear"),
    }
    include = {x for x in include if x is not None}

    texts: list[str] = []
    for row in ds["train"]:
        txt = (row.get("text") or "").strip()
        if not txt or len(txt) < min_chars:
            continue
        labs = set(row.get("labels") or [])
        if include and labs.intersection(include):
            texts.append(txt)
        if len(texts) >= max_rows:
            break
    return texts

def build_prompt(user_text: str, history_text: str, context_chunks: List[str]) -> str:
    context_str = "\n".join(context_chunks[:2]) if context_chunks else "(none)"
    return f"""
You are a supportive AI companion focused on {TOPIC_NAME}.
Be warm, practical, and concise (4–7 sentences).

If harsh self-talk → gently reframe.
If comparison → refocus on personal growth.
Ask ONE gentle follow-up question.

Retrieved context:
{context_str}

Conversation so far:
{history_text}

User message:
{user_text}

Write the best response:
""".strip()
