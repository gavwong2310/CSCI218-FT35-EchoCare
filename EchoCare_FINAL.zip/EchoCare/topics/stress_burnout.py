from __future__ import annotations
from datasets import load_dataset

TOPIC_NAME = "Stress and Burnout"
KEYWORDS = ["stress", "burnout", "overwhelmed", "pressure", "fatigue", "workload"]

def build_corpus(max_rows: int = 2000, min_chars: int = 35) -> list[str]:
    ds = load_dataset("ChuKaHang/stress_essays")
    texts = []

    for split in ds:
        for row in ds[split]:
            txt = (row.get("text") or "").strip()
            if txt and len(txt) >= min_chars:
                texts.append(txt)
            if len(texts) >= max_rows:
                return texts
    return texts


def build_prompt(user_text: str, history_text: str, context_chunks: list[str]) -> str:
    context_str = "\n".join(context_chunks) if context_chunks else "(none)"

    return f"""
You are a supportive AI companion focused on {TOPIC_NAME}.
Be practical and calm.
Suggest small actionable coping steps.
Ask one gentle follow-up question.

Retrieved context:
{context_str}

Conversation so far:
{history_text}

User message:
{user_text}

Write the best response:
""".strip()
