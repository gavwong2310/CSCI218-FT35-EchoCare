from __future__ import annotations
from datasets import load_dataset

TOPIC_NAME = "Low Mood / Sadness"
KEYWORDS = ["sad", "down", "blue", "hopeless", "empty", "numb", "worthless"]

def build_corpus(max_rows: int = 1200, min_chars: int = 35) -> list[str]:
    ds = load_dataset("google-research-datasets/go_emotions", "simplified")
    names = ds["train"].features["labels"].feature.names
    name_to_id = {n: i for i, n in enumerate(names)}

    include = {
        name_to_id.get("sadness"),
        name_to_id.get("disappointment"),
        name_to_id.get("remorse"),
        name_to_id.get("grief"),  # only used if it exists
    }
    include = {x for x in include if x is not None}

    texts: list[str] = []
    for row in ds["train"]:
        txt = (row.get("text") or "").strip()
        if not txt or len(txt) < min_chars:
            continue
        labs = set(row.get("labels") or [])
        if include and labs.intersection(include):
            texts.append(txt)
        if len(texts) >= max_rows:
            break
    return texts

def build_prompt(user_text: str, history_text: str, context_chunks: list[str]) -> str:
    context_str = "\n".join(context_chunks) if context_chunks else "(none)"
    return f"""
You are a supportive AI companion focused on {TOPIC_NAME}.
Validate first. Avoid toxic positivity.
Suggest small practical steps.
Keep response under 150 words.
Ask one gentle follow-up question.

Retrieved context:
{context_str}

Conversation so far:
{history_text}

User message:
{user_text}

Write the best response:
""".strip()