from __future__ import annotations
from typing import List

TOPIC_NAME = "Anxiety"
KEYWORDS = [
    "anxious","anxiety","panic","panicking","overthink","overthinking","worry","worried","nervous",
    "fear","scared","heart racing","tight chest","can't breathe","cant breathe","stress"
]

DATASET_NAME = "cypsiSAS/template_dataset_anxiety"

def _safe_join(chunks: list[str], max_chunks: int = 3, max_chars_each: int = 900) -> str:
    if not chunks:
        return ""
    out = []
    for c in chunks:
        if isinstance(c, str) and c.strip():
            out.append(c.strip()[:max_chars_each])
        if len(out) >= max_chunks:
            break
    return "\n\n".join(out)

def _guess_fields(row: dict) -> tuple[str|None,str|None]:
    if not isinstance(row, dict):
        return None, None
    in_keys = ["input","instruction","prompt","question","user","text","query"]
    out_keys = ["output","response","answer","assistant","label","completion"]
    u=a=None
    for k in in_keys:
        if k in row and isinstance(row[k], str) and row[k].strip():
            u=row[k].strip(); break
    for k in out_keys:
        if k in row and isinstance(row[k], str) and row[k].strip():
            a=row[k].strip(); break
    if (u is None or a is None):
        strs=[v.strip() for v in row.values() if isinstance(v,str) and v.strip()]
        if len(strs)>=2:
            u=u or strs[0]
            a=a or strs[1]
    return u,a

def build_corpus(max_rows: int = 1200, min_chars: int = 35) -> list[str]:
    """
    Build anxiety KB corpus.
    1) Try your custom anxiety dataset.
    2) Fallback to GoEmotions with fear + nervousness labels (reliable in simplified).
    """
    texts: list[str] = []

    # 1) Custom dataset
    try:
        from datasets import load_dataset
        ds = load_dataset(DATASET_NAME)
        split = "train" if "train" in ds else list(ds.keys())[0]
        rows = ds[split]
        for i in range(len(rows)):
            u, a = _guess_fields(rows[i])
            if u and len(u) >= min_chars:
                texts.append(u)
            if len(texts) >= max_rows:
                break
        if texts:
            return texts
    except Exception:
        pass

    # 2) GoEmotions fallback (fear + nervousness)
    try:
        from datasets import load_dataset
        ds = load_dataset("google-research-datasets/go_emotions", "simplified")
        names = ds["train"].features["labels"].feature.names
        name_to_id = {n: i for i, n in enumerate(names)}

        include = {name_to_id.get("fear"), name_to_id.get("nervousness")}
        include = {x for x in include if x is not None}

        for row in ds["train"]:
            txt = (row.get("text") or "").strip()
            if not txt or len(txt) < min_chars:
                continue
            labs = set(row.get("labels") or [])
            if include and labs.intersection(include):
                texts.append(txt)
            if len(texts) >= max_rows:
                break
    except Exception:
        pass

    if not texts:
        texts = [
            "I feel anxious and my heart is racing before something important.",
            "I keep overthinking and worrying about what could go wrong.",
            "I feel panic coming and my breathing feels tight and fast.",
        ]
    return texts

def _few_shots(n: int = 2) -> list[tuple[str,str]]:
    try:
        from functools import lru_cache
        from datasets import load_dataset
        @lru_cache(maxsize=1)
        def _ds():
            return load_dataset(DATASET_NAME)
        ds=_ds()
        split = "train" if "train" in ds else list(ds.keys())[0]
        rows=ds[split]
        shots=[]
        for i in range(min(len(rows), 60)):
            u,a=_guess_fields(rows[i])
            if u and a:
                shots.append((u[:280], a[:420]))
            if len(shots)>=n:
                break
        return shots
    except Exception:
        return []

def build_prompt(user_text: str, history_text: str, context_chunks: list[str]) -> str:
    context = _safe_join(context_chunks)
    shots = _few_shots(2)
    ex_block = ""
    if shots:
        ex_block = "EXAMPLES (from anxiety dataset):\n" + "\n\n".join([f"User: {u}\nAssistant: {a}" for u,a in shots])

    return f"""
You are a supportive, calm companion focused on {TOPIC_NAME} for a student audience.

STYLE:
- Warm, empathetic, non-judgmental.
- Keep it concise (120–180 words).
- Give 2–4 practical coping steps (grounding/breathing/reframing/next small action).
- Ask exactly ONE gentle follow-up question.

SAFETY:
- Do not diagnose or give medication advice.
- If the user seems in immediate danger, encourage reaching a trusted adult or local emergency services.

GROUNDING:
- If Retrieved context is present, use it for factual claims and keep them general (don’t claim it perfectly matches the user).
- If context is empty or not enough, say you’re not fully sure and ask your one clarifying question; still give general safe tips.

Conversation so far:
{history_text}

Retrieved context:
{context if context else "[No additional context retrieved]"}

{ex_block}

User message:
{user_text}

Write the best response:
""".strip()
