from __future__ import annotations
from datasets import load_dataset

TOPIC_NAME = "Loneliness and Social Isolation"
KEYWORDS = ["lonely", "alone", "isolated", "left out", "excluded", "ignored", "belonging"]

def build_corpus(max_rows: int = 5000) -> list[str]:
    ds = load_dataset("yael-katsman/Loneliness-Causes-and-Intensity")
    texts = []

    for split in ds:
        for row in ds[split]:
            for value in row.values():
                if isinstance(value, str):
                    texts.append(value)
            if len(texts) >= max_rows:
                return texts
    return texts


def build_prompt(user_text: str, history_text: str, context_chunks: list[str]) -> str:
    context_str = "\n".join(context_chunks) if context_chunks else "(none)"

    return f"""
You are a supportive AI companion focused on {TOPIC_NAME}.
Be empathetic and practical (90–150 words).

Validate feelings.
Offer two small actionable steps.
Ask one simple follow-up question.

Retrieved context:
{context_str}

Conversation so far:
{history_text}

User message:
{user_text}

Write the best response:
""".strip()
