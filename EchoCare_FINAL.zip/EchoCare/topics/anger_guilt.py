from __future__ import annotations
from datasets import load_dataset

TOPIC_NAME = "Emotional Regulation (Anger, Frustration, and Guilt)"
KEYWORDS = ["anger", "angry", "fuming", "frustrated", "frustration", "guilt", "regret", "shame"]

def build_corpus(max_rows: int = 2000, min_chars: int = 35) -> list[str]:
    ds = load_dataset("ShenLab/MentalChat16K")
    texts = []

    for split in ds:
        for row in ds[split]:
            # Try common fields
            for k in ["text", "instruction", "input", "prompt", "question"]:
                txt = (row.get(k) or "").strip() if isinstance(row, dict) else ""
                if txt and len(txt) >= min_chars:
                    texts.append(txt)
                    break

            if len(texts) >= max_rows:
                return texts

    return texts

def build_prompt(user_text: str, history_text: str, context_chunks: list[str]) -> str:
    context_str = "\n".join(context_chunks) if context_chunks else "(none)"

    return f"""
You are a supportive AI companion focused on {TOPIC_NAME}.
Be empathetic, non-judgmental, and concise (120–150 words max).

If the user is angry → suggest STOP method.
If guilty → validate and suggest one repair step.

Retrieved context:
{context_str}

Conversation so far:
{history_text}

User message:
{user_text}

Write the best response:
""".strip()
