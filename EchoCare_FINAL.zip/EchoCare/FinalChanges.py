# FinalChanges.py
# Run: py -m streamlit run FinalChanges.py
# CSCI218: EchoCare (UI layer)

import re
import textwrap

import streamlit as st
import streamlit.components.v1 as components
from orchestrator import get_response


# -----------------------------
# UI THEME
# -----------------------------
BG_MAIN = "#fffbea"      # soft bright yellow
BG_SIDEBAR = "#ffffff"   # sidebar white
TEXT_PRIMARY = "#2b2b2b"
TEXT_MUTED = "rgba(43,43,43,0.60)"


# -----------------------------
# Helpers
# -----------------------------
def _youtube_id(url: str) -> str | None:
    m = re.search(r"(?:v=|youtu\.be/)([A-Za-z0-9_\-]{6,})", url)
    return m.group(1) if m else None


def _is_crisis(text: str) -> bool:
    t = (text or "").lower()
    keywords = [
        "kill myself", "suicide", "end my life", "self harm", "self-harm",
        "hurt myself", "i want to die", "jumping down", "jump off", "overdose"
    ]
    return any(k in t for k in keywords)


# -----------------------------
# Music (YouTube + low volume + mute button)
# -----------------------------
def music_panel():
    if "music_muted" not in st.session_state:
        st.session_state.music_muted = True

    yt_url = "https://www.youtube.com/watch?v=zgEmUUmuh7Q"
    vid = _youtube_id(yt_url)

    col1, col2 = st.columns([1, 3], vertical_alignment="center")
    with col1:
        if st.session_state.music_muted:
            if st.button("🔇 Muted"):
                st.session_state.music_muted = False
                st.rerun()
        else:
            if st.button("🔊 Sound on"):
                st.session_state.music_muted = True
                st.rerun()

    with col2:
        st.caption("Soft background music (optional)")

    if not vid:
        st.info("Music embed: invalid YouTube link.")
        return

    mute_js = "player.mute();" if st.session_state.music_muted else "player.unMute();"

    # volume set lower (15)
    html = f"""
<div id="player"></div>
<script>
  var tag = document.createElement('script');
  tag.src = "https://www.youtube.com/iframe_api";
  var firstScriptTag = document.getElementsByTagName('script')[0];
  firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

  var player;

  function onYouTubeIframeAPIReady() {{
    player = new YT.Player('player', {{
      height: '0',
      width: '0',
      videoId: '{vid}',
      playerVars: {{
        'autoplay': 1,
        'controls': 0,
        'loop': 1,
        'playlist': '{vid}',
        'modestbranding': 1,
        'rel': 0
      }},
      events: {{
        'onReady': onPlayerReady
      }}
    }});
  }}

  function onPlayerReady(event) {{
    try {{
      player.setVolume(15);
      {mute_js}
      event.target.playVideo();
    }} catch(e) {{}}
  }}
</script>
"""
    components.html(html, height=0)


# -----------------------------
# CSS Theme + Layout
# -----------------------------
def apply_ui():
    st.set_page_config(page_title="EchoCare", page_icon="💬", layout="wide")

    st.markdown(
        f"""
<style>
  :root {{
    --bg: {BG_MAIN};
    --sidebar: {BG_SIDEBAR};
    --text: {TEXT_PRIMARY};
    --muted: {TEXT_MUTED};
    --softCard: rgba(255,255,255,0.72);
    --border: rgba(43,43,43,0.08);
  }}

  /* Make top bar yellow too */
  header[data-testid="stHeader"] {{
    background: var(--bg) !important;
    box-shadow: none !important;
  }}
  div[data-testid="stToolbar"] {{
    background: var(--bg) !important;
  }}

  /* Main background */
  [data-testid="stAppViewContainer"] {{
    background: var(--bg) !important;
    color: var(--text) !important;
  }}

  /* Sidebar */
  section[data-testid="stSidebar"] {{
    background: var(--sidebar) !important;
    border-right: 1px solid var(--border);
  }}

  /* Layout spacing */
  .block-container {{
    max-width: 1100px;
    padding-top: 2.6rem;
    padding-bottom: 2.2rem;
  }}

  /* True centered header */
  .ec-header {{
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;     /* ✅ center horizontally */
    justify-content: center;
    text-align: center;
    margin: 0 auto 1rem auto;
    padding-top: 0.2rem;
  }}

  .ec-title {{
    font-size: 64px;         /* ✅ bigger */
    font-weight: 950;
    letter-spacing: -0.8px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    line-height: 1.05;
  }}

  .ec-subtitle {{
    margin-top: 10px;
    font-size: 16px;
    color: var(--muted);
    max-width: 720px;
  }}

  /* Chat message soft look */
  div[data-testid="stChatMessage"] {{
    border-radius: 18px;
  }}
  div[data-testid="stChatInput"] textarea {{
    border-radius: 14px !important;
  }}

  /* Gentle "room frame" behind content */
  .ec-room {{
    background: var(--softCard);
    border: 1px solid var(--border);
    border-radius: 24px;
    padding: 14px 16px;
    position: relative;
    overflow: hidden;
    margin: 0.4rem 0 0.4rem 0;
  }}
  .ec-room::before {{
    content: "";
    position: absolute;
    inset: -2px;
    border-radius: 26px;
    padding: 2px;
    background: linear-gradient(90deg,
      rgba(255,196,87,0.90),
      rgba(255,154,162,0.55),
      rgba(152,216,255,0.55),
      rgba(255,196,87,0.90)
    );
    -webkit-mask:
      linear-gradient(#000 0 0) content-box,
      linear-gradient(#000 0 0);
    -webkit-mask-composite: xor;
    mask-composite: exclude;
    animation: glow 7s linear infinite;
    pointer-events: none;
  }}
  @keyframes glow {{
    0% {{ filter: hue-rotate(0deg); }}
    100% {{ filter: hue-rotate(360deg); }}
  }}

  /* Floating decor animations */
  @keyframes floatUpDown {{
    0% {{ transform: translateY(0); }}
    50% {{ transform: translateY(-18px); }}
    100% {{ transform: translateY(0); }}
  }}
  @keyframes driftSide {{
    0% {{ transform: translateX(0); }}
    50% {{ transform: translateX(18px); }}
    100% {{ transform: translateX(0); }}
  }}

  /* ✅ Bigger sun (DO NOT collide area) */
  .ec-sun {{
    position: fixed;
    top: 90px;
    right: 26px;
    width: 210px;     /* ✅ bigger */
    height: 210px;    /* ✅ bigger */
    z-index: 1;
    pointer-events: none;
    animation: floatUpDown 4.6s ease-in-out infinite;
  }}

  /* ✅ Bigger stickers */
  .ec-float {{
    position: fixed;
    z-index: 1;
    pointer-events: none;
    opacity: 0.86;
    font-size: 42px;   /* ✅ bigger */
    filter: drop-shadow(0 8px 14px rgba(0,0,0,0.08));
  }}

  /* ---------------------------
     RIGHT SIDE stickers
     - pushed left from sun
     - spaced out vertically
     - fills the side of chat area
     --------------------------- */
  .ec-r1 {{ top: 150px; right: 300px; animation: floatUpDown 4.1s ease-in-out infinite; }}
  .ec-r2 {{ top: 260px; right: 255px; animation: floatUpDown 5.0s ease-in-out infinite; }}
  .ec-r3 {{ top: 380px; right: 305px; animation: floatUpDown 4.6s ease-in-out infinite; }}
  .ec-r4 {{ top: 520px; right: 260px; animation: floatUpDown 5.4s ease-in-out infinite; }}
  .ec-r5 {{ top: 650px; right: 310px; animation: floatUpDown 4.9s ease-in-out infinite; }}
  .ec-r6 {{ top: 760px; right: 265px; animation: floatUpDown 5.6s ease-in-out infinite; }}

  /* ---------------------------
     LEFT SIDE stickers
     - stay OUT of sidebar
     - fill left side of chat
     --------------------------- */
  .ec-l1 {{ top: 150px; left: 355px; animation: driftSide 7.0s ease-in-out infinite; }}
  .ec-l2 {{ top: 260px; left: 395px; animation: driftSide 8.0s ease-in-out infinite; }}
  .ec-l3 {{ top: 380px; left: 345px; animation: driftSide 6.5s ease-in-out infinite; }}
  .ec-l4 {{ top: 520px; left: 405px; animation: driftSide 9.0s ease-in-out infinite; }}
  .ec-l5 {{ top: 650px; left: 355px; animation: driftSide 7.8s ease-in-out infinite; }}
  .ec-l6 {{ top: 760px; left: 395px; animation: driftSide 8.8s ease-in-out infinite; }}

  /* Avoid overlap with chat input on smaller screens */
  @media (max-height: 820px) {{
    .ec-r6, .ec-l6 {{ display: none; }}
  }}
  @media (max-height: 760px) {{
    .ec-r5, .ec-l5 {{ display: none; }}
  }}
</style>
        """,
        unsafe_allow_html=True,
    )


def header():
    st.markdown(
        """
<div class="ec-header">
  <div class="ec-title">💬 EchoCare</div>
  <div class="ec-subtitle">A listening buddy that supports you with small, gentle steps.</div>
</div>
        """,
        unsafe_allow_html=True,
    )


def decor_overlay():
    # Sun SVG scales with container size (.ec-sun width/height)
    sun_svg = """
<svg viewBox="0 0 200 200" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
  <g opacity="0.95">
    <polygon points="100,6 112,42 88,42" fill="#FFD36E"/>
    <polygon points="152,22 145,58 125,44" fill="#FFD36E"/>
    <polygon points="190,72 155,84 155,60" fill="#FFD36E"/>
    <polygon points="194,122 160,112 178,97" fill="#FFD36E"/>
    <polygon points="170,172 140,147 162,137" fill="#FFD36E"/>
    <polygon points="120,194 112,160 138,170" fill="#FFD36E"/>
    <polygon points="80,194 88,160 62,170" fill="#FFD36E"/>
    <polygon points="30,172 60,147 38,137" fill="#FFD36E"/>
    <polygon points="6,122 40,112 22,97" fill="#FFD36E"/>
    <polygon points="10,72 45,84 45,60" fill="#FFD36E"/>
    <polygon points="48,22 55,58 75,44" fill="#FFD36E"/>
  </g>

  <circle cx="100" cy="108" r="54" fill="#FFCC4D" stroke="#F3B93A" stroke-width="4"/>
  <circle cx="82" cy="104" r="6" fill="#2b2b2b"/>
  <circle cx="118" cy="104" r="6" fill="#2b2b2b"/>
  <path d="M80 130 Q100 146 120 130" fill="none" stroke="#2b2b2b" stroke-width="5" stroke-linecap="round"/>
  <circle cx="70" cy="118" r="6" fill="#FF9AA2" opacity="0.55"/>
  <circle cx="130" cy="118" r="6" fill="#FF9AA2" opacity="0.55"/>
</svg>
""".strip()

    # More stickers to fill the sides (all moving)
    html = f"""
<div class="ec-sun">{sun_svg}</div>

<!-- Right side -->
<div class="ec-float ec-r1">🌼</div>
<div class="ec-float ec-r2">✨</div>
<div class="ec-float ec-r3">🌿</div>
<div class="ec-float ec-r4">🫖</div>
<div class="ec-float ec-r5">🪴</div>
<div class="ec-float ec-r6">🦋</div>

<!-- Left side -->
<div class="ec-float ec-l1">☁️</div>
<div class="ec-float ec-l2">🌈</div>
<div class="ec-float ec-l3">🕯️</div>
<div class="ec-float ec-l4">🧸</div>
<div class="ec-float ec-l5">🌸</div>
<div class="ec-float ec-l6">🍵</div>
""".strip()

    st.markdown(textwrap.dedent(html), unsafe_allow_html=True)


# -----------------------------
# State + Sidebar
# -----------------------------
TOPICS = [
    "Anxiety",
    "Stress & Burnout",
    "Loneliness",
    "Anger / Frustration / Guilt",
    "Insecurity / Self-esteem",
    "Low Mood / Sadness",
]


def init_state():
    if "messages" not in st.session_state:
        st.session_state.messages = [
            {"role": "assistant", "content": "Hey — I’m EchoCare. I’m here to listen. What’s been on your mind lately? 🫶"}
        ]
    if "last_user" not in st.session_state:
        st.session_state.last_user = ""
    if "last_bot" not in st.session_state:
        st.session_state.last_bot = ""


def sidebar():
    with st.sidebar:
        st.markdown("### Chat settings")

        mode = st.radio("Routing", ["Auto", "Pick focus"], index=0)

        focus = None
        if mode == "Pick focus":
            focus = st.selectbox("Focus issue", TOPICS, index=0)

        st.divider()
        if st.button("Clear chat"):
            st.session_state.messages = [
                {"role": "assistant", "content": "Hey — I’m EchoCare. I’m here to listen. What’s been on your mind lately? 🫶"}
            ]
            st.session_state.last_user = ""
            st.session_state.last_bot = ""
            st.rerun()

        st.divider()
        st.markdown("### Calm room vibe")
        music_panel()

        return mode, focus


# -----------------------------
# Crisis cards (Singapore)
# -----------------------------
def crisis_cards_sg():
    st.error("I’m really sorry you’re feeling this way. I can’t help with anything that could cause harm.")
    st.markdown("If you’re in Singapore and you feel unsafe **right now**, please reach out immediately:")

    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown("#### Samaritans of Singapore (SOS)")
        st.markdown("- 24-hour Hotline: **1767**  \n- 24-hour CareText (WhatsApp): **9151 1767**")
        st.link_button("Call SOS (1767)", "tel:1767")
        st.link_button("WhatsApp SOS CareText", "https://wa.me/6591511767")

    with c2:
        st.markdown("#### SAMH Helpline")
        st.markdown("- Toll-free Helpline: **1800-283-7019**")
        st.link_button("Call SAMH", "tel:18002837019")

    with c3:
        st.markdown("#### Tinkle Friend (for children)")
        st.markdown("- Helpline: **1800 2744 788** (weekday hours)")
        st.link_button("Call Tinkle Friend", "tel:18002744788")

    st.info(
        "If you can, **tell a trusted adult** (parent/guardian/teacher) right now, "
        "or go to the nearest emergency department if you’re in immediate danger."
    )


# -----------------------------
# Feedback
# -----------------------------
def feedback_box():
    if not st.session_state.last_bot:
        return
    with st.expander("Rate the last reply (helps EchoCare improve)"):
        rating = st.slider("Usefulness", 1, 5, 3)
        comment = st.text_input("Optional comment", placeholder="e.g., too generic / helpful / wrong focus")
        if st.button("Submit rating"):
            from feedback import log_event
            log_event("data/feedback_log.jsonl", {
                "event": "user_rating",
                "rating": rating,
                "comment": comment,
                "last_user": st.session_state.last_user,
                "last_bot": st.session_state.last_bot,
            })
            st.success("Thanks — recorded ✅")


# -----------------------------
# Main
# -----------------------------
def main():
    apply_ui()
    init_state()

    mode, focus = sidebar()

    header()
    decor_overlay()

    # soft room frame spacer
    st.markdown('<div class="ec-room"></div>', unsafe_allow_html=True)

    # Render chat
    for m in st.session_state.messages:
        with st.chat_message(m["role"]):
            st.markdown(m["content"])

    user_text = st.chat_input("Type your message…")
    if user_text:
        st.session_state.messages.append({"role": "user", "content": user_text})
        st.session_state.last_user = user_text

        # Crisis flow: do NOT call LLM
        if _is_crisis(user_text):
            safe_msg = (
                "I’m really sorry you’re feeling this way. I can’t help with anything that could cause harm.\n\n"
                "Please reach out to a trusted adult right now, or contact a helpline below. "
                "If you want, you can tell me what’s making today feel so heavy, and we’ll take it one step at a time."
            )
            st.session_state.messages.append({"role": "assistant", "content": safe_msg})
            st.session_state.last_bot = safe_msg

            with st.chat_message("assistant"):
                st.markdown(safe_msg)
                crisis_cards_sg()

            st.rerun()

        # Normal flow
        focus_to_send = focus or "Anxiety"

        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                result = get_response(
                    user_text=user_text,
                    messages=st.session_state.messages,
                    mode=mode,
                    focus=focus_to_send,
                    kb_dir="data/kb",
                    model="llama3.1",
                    top_k=3,
                    entail_threshold=0.55,
                    feedback_path="data/feedback_log.jsonl",
                    show_meta=False,
                )
            st.markdown(result["reply"])

        st.session_state.messages.append({"role": "assistant", "content": result["reply"]})
        st.session_state.last_bot = result["reply"]
        st.rerun()

    feedback_box()


if __name__ == "__main__":
    main()
