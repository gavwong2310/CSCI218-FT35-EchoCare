
# feedback.py
from __future__ import annotations
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

def log_event(path: str, event: Dict[str, Any]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    event = dict(event)
    event["timestamp"] = datetime.now().isoformat(timespec="seconds")
    with p.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")
