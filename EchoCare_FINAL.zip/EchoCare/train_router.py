from __future__ import annotations
import os
import re
import json
import joblib
from dataclasses import dataclass
from typing import List, Dict, Tuple
import numpy as np
from sklearn.svm import LinearSVC
from sklearn.calibration import CalibratedClassifierCV
from datasets import load_dataset
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix


TOPICS = [
    "anxiety",
    "stress_burnout",
    "loneliness",
    "anger_guilt",
    "insecurity_selfesteem",
    "low_mood",
]

# ---------- text cleaning ----------
_ws = re.compile(r"\s+")
def clean(t: str) -> str:
    t = (t or "").strip()
    t = re.sub(r"http\S+|www\.\S+", " ", t)
    t = re.sub(r"[^a-zA-Z0-9\s'’-]", " ", t)
    t = _ws.sub(" ", t).strip().lower()
    return t

def good(t: str) -> bool:
    if not t: return False
    if len(t) < 25: return False
    if len(t.split()) < 5: return False
    return True

# ---------- template expansion (high separation) ----------
def templates() -> Dict[str, List[str]]:
    return {
        "anxiety": [
            "I keep worrying about {x} and I can't stop overthinking.",
            "My heart is racing and I feel panic when I think about {x}.",
            "I feel nervous and scared about {x}.",
            "What if {x} goes wrong? I can't calm down.",
        ],
        "stress_burnout": [
            "My workload is too much and I feel overwhelmed by deadlines.",
            "I can't switch off after work/school and I'm exhausted.",
            "I feel burnt out and drained even after resting.",
            "I have too many tasks and I don't know what to prioritise.",
        ],
        "loneliness": [
            "I feel lonely even when I'm around people.",
            "I feel left out and like nobody checks on me.",
            "I don't have anyone to talk to and I feel isolated.",
            "My friends are drifting away and I feel disconnected.",
        ],
        "anger_guilt": [
            "I snapped at someone and now I feel guilty about what I said.",
            "I'm so angry and frustrated, I feel like exploding.",
            "I regret my actions and I feel ashamed afterwards.",
            "Small things make me irritated and I can't cool down.",
        ],
        "insecurity_selfesteem": [
            "I feel like I'm not good enough compared to others.",
            "I keep seeking validation because I doubt myself.",
            "I feel like an imposter and I'm scared people will judge me.",
            "I hate myself for being so incompetent.",
        ],
        "low_mood": [
            "I feel empty and numb and nothing feels enjoyable.",
            "I feel sad and hopeless and I have no energy.",
            "I feel like nothing matters and I'm tired of everything.",
            "I just want to stay in bed and I feel heavy.",
        ],
    }

def expand_templates(n_per_topic: int = 800) -> Tuple[List[str], List[str]]:
    xs, ys = [], []
    fillers = ["exams", "presentation", "friends", "family", "work", "grades", "future", "life"]
    rng = np.random.default_rng(42)
    tmpl = templates()
    for topic, arr in tmpl.items():
        for _ in range(n_per_topic):
            t = rng.choice(arr)
            x = rng.choice(fillers)
            s = t.format(x=x)
            xs.append(clean(s))
            ys.append(topic)
    return xs, ys

# ---------- public dataset sampling ----------
def sample_go_emotions(topic: str, max_rows: int = 1500) -> List[str]:
    """
    Use GoEmotions(simplified) and map labels to our topics.
    This avoids gated datasets completely.
    """
    ds = load_dataset("google-research-datasets/go_emotions", "simplified")
    names = ds["train"].features["labels"].feature.names
    name_to_id = {n: i for i, n in enumerate(names)}

    # label mapping (only use labels that exist)
    mapping = {
        "anxiety": {"fear", "nervousness"},
        "stress_burnout": {"nervousness", "fear"},  # "stress" label doesn't exist; approximate safely
        "loneliness": {"sadness"},  # loneliness not explicit; approximate + templates do heavy lifting
        "anger_guilt": {"anger", "annoyance", "disgust", "remorse"},
        "insecurity_selfesteem": {"embarrassment", "confusion", "remorse", "disapproval", "disappointment"},
        "low_mood": {"sadness", "disappointment", "grief", "remorse"},
    }

    include_names = mapping.get(topic, set())
    include_ids = {name_to_id[n] for n in include_names if n in name_to_id}

    out = []
    for row in ds["train"]:
        txt = clean(row.get("text", ""))
        if not good(txt):
            continue
        labs = set(row.get("labels") or [])
        if include_ids and labs.intersection(include_ids):
            out.append(txt)
        if len(out) >= max_rows:
            break
    return out

def build_training_set() -> Tuple[List[str], List[str]]:
    X, y = [], []

    # 1) templates (very separable)
    Xt, yt = expand_templates(n_per_topic=900)
    X.extend(Xt); y.extend(yt)

    # 2) GoEmotions (adds realism)
    for t in TOPICS:
        rows = sample_go_emotions(t, max_rows=1200)
        X.extend(rows)
        y.extend([t] * len(rows))

    # 3) final clean filter + balance
    by_topic: Dict[str, List[str]] = {t: [] for t in TOPICS}
    for xi, yi in zip(X, y):
        if good(xi):
            by_topic[yi].append(xi)

    # balance
    target = min(len(by_topic[t]) for t in TOPICS)
    target = min(target, 2500)  # cap for speed
    Xb, yb = [], []
    rng = np.random.default_rng(123)
    for t in TOPICS:
        arr = by_topic[t]
        idx = rng.choice(len(arr), size=target, replace=False)
        for i in idx:
            Xb.append(arr[i])
            yb.append(t)

    return Xb, yb


def main():
    X, y = build_training_set()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.18, random_state=42, stratify=y
    )

    # TF-IDF + LogisticRegression (interpretable, stable)
    clf = Pipeline([
    ("tfidf", TfidfVectorizer(
        ngram_range=(1,2),
        min_df=2,
        max_df=0.95,
        sublinear_tf=True,
    )),
    ("svm", CalibratedClassifierCV(
        estimator=LinearSVC(class_weight="balanced"),
        method="sigmoid",
        cv=3,
    ))
])

    clf.fit(X_train, y_train)

    pred = clf.predict(X_test)
    acc = accuracy_score(y_test, pred)
    print("\n=== Router Training Report ===")
    print(f"Train size: {len(X_train)}  Test size: {len(X_test)}")
    print(f"Holdout accuracy: {acc*100:.2f}%\n")
    print(classification_report(y_test, pred, zero_division=0))

    os.makedirs("models", exist_ok=True)
    joblib.dump(clf, "models/router_tfidf_lr.joblib")
    print("\nSaved -> models/router_tfidf_lr.joblib")

if __name__ == "__main__":
    main()