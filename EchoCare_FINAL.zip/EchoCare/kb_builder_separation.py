from __future__ import annotations

import re
import hashlib
from typing import Dict, List, Tuple

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


_WS = re.compile(r"\s+")
_BAD = re.compile(r"[^\w\s\-\']+", re.UNICODE)

def clean_line(s: str) -> str:
    s = (s or "").strip()
    s = s.replace("\u2019", "'").replace("\u2013", "-").replace("\u2014", "-")
    s = _BAD.sub(" ", s)
    s = _WS.sub(" ", s).strip()
    return s

def dedup_keep_order(lines: List[str]) -> List[str]:
    seen = set()
    out = []
    for x in lines:
        x = clean_line(x)
        if not x:
            continue
        h = hashlib.md5(x.lower().encode("utf-8")).hexdigest()
        if h in seen:
            continue
        seen.add(h)
        out.append(x)
    return out

def length_filter(lines: List[str], min_chars: int = 35, max_chars: int = 260) -> List[str]:
    out = []
    for x in lines:
        x = x.strip()
        if min_chars <= len(x) <= max_chars:
            out.append(x)
    return out


def anchor_lines() -> Dict[str, List[str]]:
    """
    Distinctive 'anchor' lines to improve separability for TF-IDF routing.
    """
    return {
        "Anxiety": [
            "Anxiety often shows up as worry about the future and lots of what-if thoughts.",
            "Physical anxiety can feel like racing heart, tight chest, shaky hands, or short breath.",
            "A grounding tool is 5-4-3-2-1: name 5 things you see, 4 you feel, 3 you hear, 2 you smell, 1 you taste.",
            "A simple breathing tool is inhale 4 seconds, exhale 6 seconds, repeat for 1 minute.",
            "Anxiety is fear-based: your brain predicts danger even when you may be safe."
        ],
        "Stress & Burnout": [
            "Stress and burnout are often linked to overload, deadlines, and not being able to switch off.",
            "Burnout can include emotional exhaustion, feeling numb, and reduced performance over time.",
            "A practical tool is workload triage: Must do, Should do, Could do. Start with one Must task.",
            "Boundary sentence: I can complete X by Friday, but Y will need more time.",
            "Micro-breaks help stress: stretch 2 minutes, drink water, then restart one small task."
        ],
        "Loneliness": [
            "Loneliness is not just being alone; it is feeling disconnected, unseen, or not understood.",
            "A small step is one intentional connection: message one trusted person with a simple invitation.",
            "Low-pressure social step: say hi, ask one small question, then exit politely if needed.",
            "Loneliness language often includes: left out, excluded, no one checks on me, no one understands.",
            "Routine helps: one weekly group activity can slowly rebuild belonging."
        ],
        "Anger / Frustration / Guilt": [
            "Anger often protects deeper feelings like hurt, fear, or unfairness.",
            "De-escalation tool: STOP (Stop, Take a breath, Observe, Proceed).",
            "Frustration is often about blocked goals; name the goal and the obstacle clearly.",
            "Guilt is about an action; shame is about the self. A repair step can reduce guilt.",
            "Repair example: apologise briefly, say what you will change, then follow through."
        ],
        "Insecurity / Self-esteem": [
            "Insecurity can sound like: I'm not good enough, people will judge me, I don't belong.",
            "A helpful reframe is: I'm having the thought that I'm not good enough (a thought is not a fact).",
            "Imposter feelings happen when you discount your wins and overfocus on flaws.",
            "Evidence check: list one thing you did well and one thing you can improve next time.",
            "Stop comparison by focusing on control: one small skill you can practice today."
        ],
        "Low Mood / Sadness": [
            "Low mood can feel like heaviness, low energy, numbness, or not enjoying things you usually enjoy.",
            "A micro-step is activation: one small task (shower, short walk, tidy desk) before motivation appears.",
            "Sadness language often includes: empty, hopeless, drained, nothing matters.",
            "Mood basics: sleep, food, sunlight, and a small routine can help.",
            "Validate first, then suggest one tiny step, not big life changes."
        ],
    }


def enforce_topic_separation(
    topic_to_lines: Dict[str, List[str]],
    min_margin: float = 0.03,
    min_keep_per_topic: int = 250,
    max_keep_per_topic: int = 1200,
    ngram_range: Tuple[int, int] = (1, 2),
) -> Dict[str, List[str]]:
    """
    Keep a line only if it matches its own topic more than others by >= min_margin.
    BUT: never output tiny KBs. If too few lines remain, fall back to original lines.
    """
    topics = list(topic_to_lines.keys())

    all_lines: List[str] = []
    line_topic: List[str] = []
    for t in topics:
        for s in topic_to_lines[t]:
            all_lines.append(s)
            line_topic.append(t)

    vec = TfidfVectorizer(
        lowercase=True,
        ngram_range=ngram_range,
        min_df=1,          # IMPORTANT: don't kill rare words
        max_df=0.95,
        sublinear_tf=True,
    )
    X = vec.fit_transform(all_lines)

    # centroids
    centroids = []
    for t in topics:
        idx = [i for i, tt in enumerate(line_topic) if tt == t]
        if not idx:
            centroids.append(np.zeros((1, X.shape[1])))
        else:
            centroids.append(X[idx].mean(axis=0))
    C = np.vstack([np.asarray(c).reshape(1, -1) for c in centroids])

    kept: Dict[str, List[str]] = {t: [] for t in topics}

    for i, s in enumerate(all_lines):
        sims = cosine_similarity(X[i], C)[0]
        best_idx = int(np.argmax(sims))
        best_topic = topics[best_idx]
        best = float(sims[best_idx])

        sims_sorted = np.sort(sims)
        second = float(sims_sorted[-2]) if len(sims_sorted) >= 2 else 0.0
        margin = best - second

        true_t = line_topic[i]
        if best_topic == true_t and margin >= min_margin:
            kept[true_t].append(s)

    # postprocess + fallback
    for t in topics:
        lines = dedup_keep_order(kept[t])
        lines = length_filter(lines, 35, 260)

        if len(lines) < min_keep_per_topic:
            fallback = dedup_keep_order(topic_to_lines[t])
            fallback = length_filter(fallback, 35, 260)
            lines = fallback[:max_keep_per_topic]
        else:
            lines = lines[:max_keep_per_topic]

        kept[t] = lines

    return kept
