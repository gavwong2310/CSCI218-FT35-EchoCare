# routing_accuracy.py
# Run: py routing_accuracy.py --test routing_test.csv --outdir reports

from __future__ import annotations
import argparse
import csv
import os
from collections import Counter
from typing import List, Tuple
import matplotlib.pyplot as plt
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    accuracy_score,
    precision_recall_fscore_support,
)

from orchestrator import route_topic, TOPICS


# -------------------------
# IO
# -------------------------
def read_test_csv(path: str) -> Tuple[List[str], List[str]]:
    texts, labels = [], []
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            raise ValueError("CSV has no headers. Expected: text, expected_topic")

        required = {"text", "expected_topic"}
        missing = required - set(reader.fieldnames)
        if missing:
            raise ValueError(f"CSV is missing headers: {', '.join(sorted(missing))}")

        for row in reader:
            t = (row.get("text") or "").strip()
            y = (row.get("expected_topic") or "").strip()
            if not t or not y:
                continue
            texts.append(t)
            labels.append(y)
    return texts, labels

def ensure_outdir(outdir: str):
    os.makedirs(outdir, exist_ok=True)

def save_fig(path: str):
    plt.tight_layout()
    plt.savefig(path, dpi=220)
    plt.close()

def plot_donut(correct: int, total: int, title: str, outpath: str):
    wrong = max(total - correct, 0)
    sizes = [correct, wrong]
    labels = ["Correct", "Incorrect"]
    plt.figure(figsize=(5.2, 5.2))
    plt.pie(sizes, labels=labels, startangle=90, wedgeprops=dict(width=0.45))
    plt.title(title)
    save_fig(outpath)

def plot_hist(values, title, xlabel, ylabel, outpath, bins=16):
    plt.figure(figsize=(8.5, 4.8))
    plt.hist(values, bins=bins)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    save_fig(outpath)

def plot_bar(labels, values, title, xlabel, ylabel, outpath, rotate=25):
    plt.figure(figsize=(9, 4.8))
    plt.bar(labels, values)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    if rotate:
        plt.xticks(rotation=rotate, ha="right")
    save_fig(outpath)

def plot_confusion_normalized(cm, labels, outpath):
    """
    Row-normalized confusion matrix with count + row% in each cell.
    Improved readability: lighter colormap + bold text + auto text color.
    """
    import numpy as np
    import matplotlib.pyplot as plt

    cm = np.asarray(cm, dtype=float)
    row_sums = cm.sum(axis=1, keepdims=True)

    with np.errstate(divide="ignore", invalid="ignore"):
        cm_norm = np.divide(cm, row_sums, where=row_sums != 0)
        cm_norm = np.nan_to_num(cm_norm)

    fig_w = max(8.5, 1.0 * len(labels))
    fig_h = max(7.0, 0.85 * len(labels))
    fig, ax = plt.subplots(figsize=(fig_w, fig_h))

    # Lighter, presentation-friendly colormap
    im = ax.imshow(cm_norm, aspect="auto", cmap="Blues", vmin=0.0, vmax=1.0)

    ax.set_title("Confusion Matrix (Row-normalized) — count (row%)")
    ax.set_xlabel("Predicted topic")
    ax.set_ylabel("True topic")

    ax.set_xticks(range(len(labels)))
    ax.set_yticks(range(len(labels)))
    ax.set_xticklabels(labels, rotation=35, ha="right")
    ax.set_yticklabels(labels)

    # Draw gridlines for readability
    ax.set_xticks(np.arange(-.5, len(labels), 1), minor=True)
    ax.set_yticks(np.arange(-.5, len(labels), 1), minor=True)
    ax.grid(which="minor", color="white", linestyle="-", linewidth=1)
    ax.tick_params(which="minor", bottom=False, left=False)

    # Annotate cells with dynamic text color + bold font
    for i in range(len(labels)):
        for j in range(len(labels)):
            count = int(cm[i, j])
            pct = cm_norm[i, j] * 100.0

            txt = f"{count}\n({pct:.0f}%)" if row_sums[i, 0] > 0 else f"{count}\n(0%)"

            # Auto-contrast: white text on dark cells, black on light cells
            text_color = "white" if cm_norm[i, j] >= 0.5 else "black"

            ax.text(
                j, i, txt,
                ha="center", va="center",
                fontsize=10,
                fontweight="bold",
                color=text_color
            )

    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    save_fig(outpath)

def write_predictions_csv(path: str, X, y_true, y_pred, confs):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["text", "expected_topic", "pred_topic", "route_confidence", "correct"])
        for t, yt, yp, c in zip(X, y_true, y_pred, confs):
            w.writerow([t, yt, yp, f"{c:.6f}", "1" if yt == yp else "0"])

def write_errors_csv(path: str, X, y_true, y_pred, confs, max_rows=30):
    wrong = [(X[i], y_true[i], y_pred[i], confs[i]) for i in range(len(X)) if y_true[i] != y_pred[i]]
    # sort by lowest confidence first (easier to explain: ambiguous cases)
    wrong.sort(key=lambda z: z[3])
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["text", "expected_topic", "pred_topic", "route_confidence", "why_explain"])
        for t, yt, yp, c in wrong[:max_rows]:
            # leave a column for you to type 1-line explanations later
            w.writerow([t, yt, yp, f"{c:.6f}", ""])

def plot_top_confusions(y_true, y_pred, labels, outpath, top_k=10):
    """
    Show only the dominant error pairs: (true -> predicted) counts.
    This avoids the 'ugly matrix' problem and is super explainable to lecturers.
    """
    pair_counts = Counter()
    for yt, yp in zip(y_true, y_pred):
        if yt != yp:
            pair_counts[(yt, yp)] += 1

    if not pair_counts:
        # no errors: produce a tiny placeholder plot
        plt.figure(figsize=(8.0, 3.8))
        plt.title("Top Confusions (No errors)")
        plt.text(0.5, 0.5, "No misclassifications found.", ha="center", va="center")
        plt.axis("off")
        save_fig(outpath)
        return

    top = pair_counts.most_common(top_k)
    x_labels = [f"{a} → {b}" for (a, b), _ in top]
    values = [c for _, c in top]

    plt.figure(figsize=(10.5, 5.2))
    plt.bar(x_labels, values)
    plt.title(f"Top {min(top_k, len(top))} Confusion Pairs (Errors Only)")
    plt.xlabel("True → Predicted")
    plt.ylabel("Count")
    plt.xticks(rotation=30, ha="right")
    save_fig(outpath)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--test", default="routing_test.csv", help="Path to labelled test CSV")
    ap.add_argument("--kb", default="data/kb", help="KB directory used for routing corpora")
    ap.add_argument("--min_conf", type=float, default=0.0, help="Treat predictions below this as 'Uncertain'")
    ap.add_argument("--outdir", default="reports", help="Where to save plots and CSV outputs")
    args = ap.parse_args()

    ensure_outdir(args.outdir)

    X, y_true = read_test_csv(args.test)

    # Validate labels
    unknown = sorted(set(y_true) - set(TOPICS))
    if unknown:
        raise ValueError(
            "Found labels not in TOPICS:\n"
            + "\n".join(unknown)
            + "\n\nAllowed TOPICS:\n"
            + "\n".join(TOPICS)
        )

    y_pred = []
    confs = []

    for text in X:
        pred, conf, _ = route_topic(text, args.kb)
        if conf < args.min_conf:
            pred = "Uncertain"
        y_pred.append(pred)
        confs.append(float(conf))

    # Labels for metrics / confusion matrix
    labels = TOPICS.copy()
    if "Uncertain" in y_pred and "Uncertain" not in labels:
        labels.append("Uncertain")

    acc = accuracy_score(y_true, y_pred)
    print("\n" + "=" * 64)
    print("EchoCare Routing Accuracy Report (Classical NLP TF-IDF Router)")
    print("=" * 64)
    print(f"Test file: {args.test}")
    print(f"KB dir:    {args.kb}")
    print(f"Samples:   {len(y_true)}")
    print(f"Accuracy:  {acc*100:.2f}%")
    print("\n--- Classification Report ---")
    print(classification_report(y_true, y_pred, labels=labels, zero_division=0))

    # -------------------------
    # Lecturer-friendly outputs
    # -------------------------
    # 1) Confusion matrix (row-normalized) with count+%
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    plot_confusion_normalized(
        cm=cm,
        labels=labels,
        outpath=os.path.join(args.outdir, "confusion_matrix_normalized.png"),
    )

    # 2) Top confusions (errors only)
    plot_top_confusions(
        y_true=y_true,
        y_pred=y_pred,
        labels=labels,
        outpath=os.path.join(args.outdir, "top_confusions.png"),
        top_k=10,
    )

    # 3) Per-topic F1 and support
    precision, recall, f1, support = precision_recall_fscore_support(
        y_true, y_pred, labels=labels, zero_division=0
    )
    # F1 per topic
    plot_bar(
        labels=labels,
        values=[float(x) for x in f1],
        title="F1-score per Topic (Classical Router)",
        xlabel="Topic",
        ylabel="F1",
        outpath=os.path.join(args.outdir, "per_topic_f1.png"),
        rotate=25,
    )
    # Support per topic
    plot_bar(
        labels=labels,
        values=[int(x) for x in support],
        title="Support per Topic (Number of Test Samples)",
        xlabel="Topic",
        ylabel="Support",
        outpath=os.path.join(args.outdir, "support_per_topic.png"),
        rotate=25,
    )

    # 4) Correct vs incorrect donut
    correct = sum(1 for yt, yp in zip(y_true, y_pred) if yt == yp)
    plot_donut(
        correct=correct,
        total=len(y_true),
        title="Overall Routing Correctness",
        outpath=os.path.join(args.outdir, "correct_incorrect_donut.png"),
    )

    # 5) Confidence histogram
    plot_hist(
        values=confs,
        title="Router Confidence Distribution",
        xlabel="route_confidence",
        ylabel="Count",
        outpath=os.path.join(args.outdir, "confidence_hist.png"),
        bins=16,
    )

    # 6) CSV exports (appendix-friendly)
    write_predictions_csv(os.path.join(args.outdir, "predictions.csv"), X, y_true, y_pred, confs)
    write_errors_csv(os.path.join(args.outdir, "errors_examples.csv"), X, y_true, y_pred, confs)

    print(f"\nSaved plots + CSVs to -> {args.outdir}")
    print("=" * 64 + "\n")
    


if __name__ == "__main__":
    main()