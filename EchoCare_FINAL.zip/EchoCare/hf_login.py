from huggingface_hub import login
login(token="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")
print("HuggingFace login success")