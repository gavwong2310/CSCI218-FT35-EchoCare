
# rag.py
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple
import streamlit as st

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def _read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""


def _chunk_text(text: str, max_chars: int = 900) -> List[str]:
    # simple paragraph-based chunking
    paras = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks: List[str] = []
    for p in paras:
        if len(p) <= max_chars:
            chunks.append(p)
        else:
            # hard split long paragraphs
            for i in range(0, len(p), max_chars):
                chunks.append(p[i:i+max_chars])
    return chunks


@dataclass
class TopicIndex:
    chunks: List[str]
    vectorizer: TfidfVectorizer
    matrix: object  # sparse matrix


@st.cache_resource
def build_indices(kb_dir: str) -> Dict[str, TopicIndex]:
    kb_path = Path(kb_dir)
    indices: Dict[str, TopicIndex] = {}

    for txt in kb_path.glob("*.txt"):
        topic_key = txt.stem  # e.g., "anxiety_kb"
        text = _read_text(txt)
        chunks = _chunk_text(text)
        # fallback if empty
        if not chunks:
            chunks = ["(no knowledge base content found for this topic yet)"]

        vec = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), min_df=1)
        mat = vec.fit_transform(chunks)
        indices[topic_key] = TopicIndex(chunks=chunks, vectorizer=vec, matrix=mat)

    return indices


def retrieve(indices: Dict[str, TopicIndex],
             topic_key: str,
             query: str,
             top_k: int = 3,
             min_sim: float = 0.12) -> List[Tuple[str, float]]:
    if topic_key not in indices:
        return []
    ti = indices[topic_key]
    qv = ti.vectorizer.transform([query])
    sims = cosine_similarity(qv, ti.matrix).flatten()
    # rank
    ranked = sims.argsort()[::-1]
    out: List[Tuple[str, float]] = []
    for idx in ranked[:top_k]:
        score = float(sims[idx])
        if score < min_sim:
            continue
        out.append((ti.chunks[idx], score))
    return out
