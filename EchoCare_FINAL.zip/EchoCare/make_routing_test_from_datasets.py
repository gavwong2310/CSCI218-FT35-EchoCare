from __future__ import annotations
import csv
import random
import re
from datasets import load_dataset

random.seed(42)

TOPICS = [
    "Anxiety",
    "Stress & Burnout",
    "Loneliness",
    "Anger / Frustration / Guilt",
    "Insecurity / Self-esteem",
    "Low Mood / Sadness",
]

def clean(t: str) -> str:
    t = (t or "").strip()
    t = re.sub(r"http\S+|www\.\S+", " ", t)
    t = re.sub(r"\s+", " ", t)
    return t

def good(t: str) -> bool:
    return t and len(t) >= 25 and len(t.split()) >= 5


def build_from_goemotions(per_topic=600):
    ds = load_dataset("google-research-datasets/go_emotions", "simplified")
    names = ds["train"].features["labels"].feature.names
    name_to_id = {n: i for i, n in enumerate(names)}

    mapping = {
        "Anxiety": {"fear", "nervousness"},
        "Stress & Burnout": {"nervousness", "fear"},
        "Loneliness": {"sadness"},
        "Anger / Frustration / Guilt": {"anger", "annoyance", "disgust", "remorse"},
        "Insecurity / Self-esteem": {"embarrassment", "confusion", "disapproval", "disappointment"},
        "Low Mood / Sadness": {"sadness", "grief", "remorse"},
    }

    topic_data = {t: [] for t in TOPICS}

    for row in ds["train"]:
        text = clean(row["text"])
        if not good(text):
            continue

        labels = set(row["labels"])

        for topic, label_names in mapping.items():
            ids = {name_to_id[n] for n in label_names if n in name_to_id}
            if labels.intersection(ids):
                topic_data[topic].append(text)

    # Balance
    rows = []
    for topic in TOPICS:
        data = topic_data[topic]
        if len(data) < per_topic:
            print(f"[WARN] {topic} only has {len(data)} samples")
            sample = data
        else:
            sample = random.sample(data, per_topic)
        for s in sample:
            rows.append((s, topic))

    random.shuffle(rows)
    return rows


def build_from_loneliness(per_topic=600):
    ds = load_dataset("yael-katsman/Loneliness-Causes-and-Intensity")
    rows = []

    for row in ds["train"]:
        text = clean(row.get("text", ""))
        if good(text):
            rows.append((text, "Loneliness"))

    random.shuffle(rows)
    return rows[:per_topic]


def main(out_csv="routing_test.csv", per_topic=600):
    rows = []

    # GoEmotions covers most topics
    rows.extend(build_from_goemotions(per_topic))

    # Extra loneliness from dedicated dataset
    rows.extend(build_from_loneliness(per_topic))

    random.shuffle(rows)

    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["text", "expected_topic"])
        w.writerows(rows)

    print(f"Wrote {len(rows)} samples to {out_csv}")


if __name__ == "__main__":
    main()