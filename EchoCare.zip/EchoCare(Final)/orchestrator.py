# orchestrator.py
# EchoCare core pipeline:
# 1) Classical NLP routing (TF-IDF similarity across topic corpora)
# 2) RAG retrieval (TF-IDF over KB chunks)
# 3) Llama generation (Ollama) grounded on retrieved context
# 4) Entailment checker gate (MNLI) to reduce hallucination (applied smartly)
# 5) Feedback logging (JSONL)

from __future__ import annotations

import os
import re
import time
import random
from typing import Dict, List, Tuple

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from llama_wrapper import ollama_chat
from feedback import log_event

# Topic prompt builders (each file belongs to one teammate)
from topics.anxiety import build_prompt as build_prompt_anxiety
from topics.stress_burnout import build_prompt as build_prompt_stress
from topics.loneliness import build_prompt as build_prompt_lonely
from topics.anger_guilt import build_prompt as build_prompt_anger
from topics.insecurity_selfesteem import build_prompt as build_prompt_insec
from topics.low_mood import build_prompt as build_prompt_lowmood

# Entailment checker
from entailment import score_entailment


# -----------------------------
# Topic / KB configuration
# -----------------------------
TOPICS = [
    "Anxiety",
    "Stress & Burnout",
    "Loneliness",
    "Anger / Frustration / Guilt",
    "Insecurity / Self-esteem",
    "Low Mood / Sadness",
]

KB_FILES = {
    "Anxiety": "anxiety_kb.txt",
    "Stress & Burnout": "stress_burnout_kb.txt",
    "Loneliness": "loneliness_kb.txt",
    "Anger / Frustration / Guilt": "anger_guilt_kb.txt",
    "Insecurity / Self-esteem": "insecurity_selfesteem_kb.txt",
    "Low Mood / Sadness": "low_mood_kb.txt",
}

PROMPT_BUILDERS = {
    "Anxiety": build_prompt_anxiety,                         # Gavin
    "Stress & Burnout": build_prompt_stress,                 # Sueiqii
    "Loneliness": build_prompt_lonely,                       # En Chen
    "Anger / Frustration / Guilt": build_prompt_anger,       # Lanice
    "Insecurity / Self-esteem": build_prompt_insec,          # Albert
    "Low Mood / Sadness": build_prompt_lowmood,              # Jerald
}


# -----------------------------
# Safety filter (lightweight, non-graphic)
# -----------------------------
def _safety_check(user_text: str) -> Tuple[bool, str]:
    """
    Teen-safe: refuse harmful requests; encourage trusted adult / emergency services.
    """
    t = user_text.lower()

    risky = [
        "kill myself", "suicide", "self harm", "self-harm", "end my life", "hurt myself",
        "how do i kill myself", "how to kill myself", "how do i die",
        "jump off", "jumping", "jump", "want to die", "i want to die",
        "no reason to live", "can't go on", "cant go on",
    ]

    if any(k in t for k in risky):
        templates = [
            "I’m really sorry you’re feeling this way. I can’t help with anything that could cause harm.\n\n"
            "Please tell a trusted adult right now (parent/guardian/teacher), or contact local emergency services if you feel unsafe. "
            "If you want, you can tell me what’s making today feel so heavy, and we’ll take it one step at a time.",

            "I’m really sorry you’re going through this. I can’t help with requests about harming yourself.\n\n"
            "Please reach out to a trusted adult immediately, or contact local emergency services if you feel in danger. "
            "If you want, you can share what happened today and what you’re feeling right now.",

            "I’m sorry you’re feeling this overwhelmed. I can’t help with anything that could lead to harm.\n\n"
            "Please get support from a trusted adult right now, or call local emergency services if you feel unsafe. "
            "If you’re able, tell me what’s been building up — we can take it slowly.",
        ]
        return False, random.choice(templates)

    return True, ""


# -----------------------------
# Utilities: history + chunking
# -----------------------------
def _compact_history(messages: List[Dict], max_turns: int = 8) -> str:
    last = messages[-max_turns:]
    lines = []
    for m in last:
        role = m.get("role", "")
        content = (m.get("content", "") or "").strip()
        if not content:
            continue
        if role == "user":
            lines.append(f"User: {content}")
        elif role == "assistant":
            lines.append(f"Assistant: {content}")
    return "\n".join(lines)


def _split_kb_into_chunks(text: str, max_chars: int = 900) -> List[str]:
    paras = [p.strip() for p in re.split(r"\n\s*\n+", text) if p.strip()]
    chunks = []
    for p in paras:
        if len(p) <= max_chars:
            chunks.append(p)
        else:
            for i in range(0, len(p), max_chars):
                chunks.append(p[i : i + max_chars].strip())
    return chunks


# -----------------------------
# Classical NLP router (TF-IDF)
# -----------------------------
_router_vectorizer: TfidfVectorizer | None = None
_router_topic_matrix = None
_router_topic_texts: List[str] | None = None
_router_kb_dir: str | None = None


def _load_topic_corpora(kb_dir: str) -> List[str]:
    corpora = []
    for topic in TOPICS:
        path = os.path.join(kb_dir, KB_FILES[topic])
        try:
            with open(path, "r", encoding="utf-8") as f:
                corpora.append(f.read())
        except Exception:
            corpora.append("")
    return corpora


def route_topic_tfidf(user_text: str, kb_dir: str) -> Tuple[str, float]:
    global _router_vectorizer, _router_topic_matrix, _router_topic_texts, _router_kb_dir

    if (
        _router_vectorizer is None
        or _router_topic_matrix is None
        or _router_topic_texts is None
        or _router_kb_dir != kb_dir
    ):
        _router_topic_texts = _load_topic_corpora(kb_dir)
        _router_vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), min_df=1)
        _router_topic_matrix = _router_vectorizer.fit_transform(_router_topic_texts)
        _router_kb_dir = kb_dir

    q = _router_vectorizer.transform([user_text])
    sims = cosine_similarity(q, _router_topic_matrix)[0]
    best_idx = int(sims.argmax())
    return TOPICS[best_idx], float(sims[best_idx])


# -----------------------------
# RAG retrieval (TF-IDF chunks)
# -----------------------------
_rag_cache: Dict[Tuple[str, str], Dict] = {}
# key: (kb_dir, topic) -> {"vectorizer":..., "matrix":..., "chunks":[...]}

def retrieve_context(user_text: str, topic: str, kb_dir: str, top_k: int = 3) -> Tuple[List[str], List[float]]:
    key = (kb_dir, topic)
    if key not in _rag_cache:
        kb_path = os.path.join(kb_dir, KB_FILES[topic])
        try:
            with open(kb_path, "r", encoding="utf-8") as f:
                kb_text = f.read()
        except Exception:
            kb_text = ""

        chunks = _split_kb_into_chunks(kb_text, max_chars=900)
        if not chunks:
            chunks = [""]

        vec = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), min_df=1)
        mat = vec.fit_transform(chunks)

        _rag_cache[key] = {"vectorizer": vec, "matrix": mat, "chunks": chunks}

    vec = _rag_cache[key]["vectorizer"]
    mat = _rag_cache[key]["matrix"]
    chunks = _rag_cache[key]["chunks"]

    q = vec.transform([user_text])
    sims = cosine_similarity(q, mat)[0]

    top_k = max(1, min(top_k, len(chunks)))
    idxs = sims.argsort()[::-1][:top_k]

    picked = [chunks[i] for i in idxs if chunks[i].strip()]
    scores = [float(sims[i]) for i in idxs if chunks[i].strip()]
    return picked, scores


# -----------------------------
# Smarter entailment gating
# -----------------------------
def _is_general_emotional_support(user_text: str) -> bool:
    """
    For very short “I feel X” messages, entailment is NOT a good gate,
    because good responses are empathic, not strictly entailed by KB text.
    """
    t = user_text.lower().strip()
    patterns = [
        "i feel anxious", "feeling anxious", "im anxious", "i am anxious",
        "i feel stressed", "feeling stressed", "im stressed", "i am stressed",
        "i feel sad", "feeling sad", "im sad", "i am sad",
        "i feel lonely", "feeling lonely", "im lonely", "i am lonely",
        "i feel angry", "feeling angry", "im angry", "i am angry",
    ]
    return any(p in t for p in patterns) and len(t) <= 45


def _is_more_factual_query(user_text: str) -> bool:
    """
    Use entailment for questions likely to trigger factual claims.
    """
    t = user_text.lower()
    triggers = ["what is", "why", "how does", "difference", "causes", "symptoms", "will it", "is it true", "can i"]
    return any(x in t for x in triggers)


def _safe_fallback(user_text: str, context_chunks: List[str]) -> str:
    """
    Final fallback if entailment fails twice.
    Keep it supportive + 1 question, and avoid inventing facts.
    """
    if context_chunks:
        bullets = "\n".join([f"- {c[:160].strip()}" for c in context_chunks[:3]])
        return (
            "I want to make sure I’m not guessing. Based on what I can confidently support right now:\n"
            f"{bullets}\n\n"
            "What part feels the hardest right now — the thoughts, the body feelings, or the situation?"
        )
    return (
        "I want to make sure I understand you properly before I say anything that might be off. "
        "Could you share a little more about what happened and what you’re feeling right now?"
    )


def _second_try_grounded(prompt: str) -> str:
    """
    Add stricter grounding instruction to reduce hallucination + reduce repetition.
    """
    return (
        prompt
        + "\n\nIMPORTANT:\n"
          "- Use ONLY the retrieved context for factual claims.\n"
          "- If context is not enough, say you’re not sure and ask ONE clarifying question.\n"
          "- Do NOT repeat yourself.\n"
    )


# -----------------------------
# Main API called by FinalChanges.py
# -----------------------------
def get_response(
    user_text: str,
    messages: List[Dict],
    mode: str,
    focus: str,
    kb_dir: str,
    model: str,
    top_k: int,
    entail_threshold: float,
    feedback_path: str,
    show_meta: bool = False,
) -> Dict[str, str]:
    t0 = time.time()

    # Safety first
    allowed, safety_reply = _safety_check(user_text)
    if not allowed:
        log_event(feedback_path, {"event": "blocked_by_safety", "user_text": user_text})
        return {"reply": safety_reply, "meta": "safety_block" if show_meta else ""}

    # 1) Classical NLP routing
    if mode == "Pick focus":
        topic = focus
        route_conf = 1.0
        route_meta = "manual_focus"
    else:
        topic, route_conf = route_topic_tfidf(user_text, kb_dir)
        route_meta = "tfidf_route"

    # 2) RAG retrieval
    context_chunks, rag_scores = retrieve_context(user_text, topic, kb_dir, top_k=top_k)

    # 3) Build prompt (topic-specific)
    history_text = _compact_history(messages, max_turns=8)
    builder = PROMPT_BUILDERS.get(topic, build_prompt_anxiety)
    prompt = builder(user_text=user_text, history_text=history_text, context_chunks=context_chunks)

    system = (
        "You are EchoCare, a warm listening buddy. "
        "Be supportive, concise, and avoid repeating yourself. "
        "Do not invent facts. If context is insufficient, ask one clarifying question."
    )

    # 4) Llama generation
    # IMPORTANT: avoid passing history twice -> we already include history_text in prompt
    reply = ollama_chat(
        prompt=prompt,
        history=[],  # <-- prevents repetition from double-conditioning
        model=model,
        system=system,
        options={
            "temperature": 0.45,
            "top_p": 0.9,
            "repeat_penalty": 1.2,
            "num_ctx": 2048,
            "num_predict": 220,
            "repeat_last_n": 64,  # helps reduce loops (supported by Ollama)
        }
    ).strip()

    # 5) Entailment gate (smart application)
    premise = "\n\n".join(context_chunks[:3]).strip()
    entail_score = None
    passed = True
    used_retry = False

    should_gate = (
        bool(premise)
        and _is_more_factual_query(user_text)
        and not _is_general_emotional_support(user_text)
    )

    if should_gate:
        try:
            entail_score = float(score_entailment(premise=premise, hypothesis=reply))
            passed = entail_score >= float(entail_threshold)
        except Exception:
            entail_score = None
            passed = True

        # If failed, do one stricter retry before fallback
        if not passed:
            used_retry = True
            retry_prompt = _second_try_grounded(prompt)
            retry_reply = ollama_chat(
                prompt=retry_prompt,
                history=[],
                model=model,
                system=system,
                options={
                    "temperature": 0.30,
                    "top_p": 0.85,
                    "repeat_penalty": 1.25,
                    "num_ctx": 2048,
                    "num_predict": 200,
                    "repeat_last_n": 64,
                }
            ).strip()

            # Re-check entailment once
            try:
                entail_score = float(score_entailment(premise=premise, hypothesis=retry_reply))
                passed = entail_score >= float(entail_threshold)
                reply = retry_reply if retry_reply else reply
            except Exception:
                reply = retry_reply if retry_reply else reply
                passed = True

            if not passed:
                reply = _safe_fallback(user_text=user_text, context_chunks=context_chunks)

    # 6) Log system event (feedback loop inside system)
    log_event(feedback_path, {
        "event": "turn",
        "user_text": user_text,
        "topic": topic,
        "route_method": route_meta,
        "route_confidence": route_conf,
        "rag_top_k": top_k,
        "rag_scores": rag_scores,
        "entail_threshold": entail_threshold,
        "entail_score": entail_score,
        "entail_pass": passed,
        "entail_used": should_gate,
        "entail_retry_used": used_retry,
        "model": model,
        "latency_sec": round(time.time() - t0, 3),
    })

    meta = ""
    if show_meta:
        meta = (
            f"topic={topic} | route={route_meta}({route_conf:.3f}) | "
            f"rag_scores={['{:.3f}'.format(s) for s in rag_scores[:3]]} | "
            f"entail_used={should_gate} | "
            f"entail={('n/a' if entail_score is None else f'{entail_score:.3f}')} | "
            f"pass={passed} | retry={used_retry}"
        )

    return {"reply": reply, "meta": meta}


