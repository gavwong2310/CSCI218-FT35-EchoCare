# entailment.py
# Uses MNLI model to check if reply is supported by retrieved context

from transformers import pipeline

# Load once (cached in memory)
_entailment_model = pipeline(
    "text-classification",
    model="facebook/bart-large-mnli",
    return_all_scores=True
)


def score_entailment(premise: str, hypothesis: str) -> float:
    """
    Returns entailment probability between 0 and 1.
    premise = retrieved context
    hypothesis = LLM reply
    """

    if not premise.strip() or not hypothesis.strip():
        return 0.0

    result = _entailment_model(
        f"{premise} </s></s> {hypothesis}"
    )[0]

    # Find entailment label
    for r in result:
        if r["label"].lower() == "entailment":
            return float(r["score"])

    return 0.0

