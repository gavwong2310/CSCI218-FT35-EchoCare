# ============================================================
# self_esteem_self_doubt.py
# Name: Albert Librantono
#
# DO NOTE THAT:
# - This file ONLY builds the prompt string for Llama.
# - No Streamlit, Hugging Face token, or model calls here.
# - RAG + entailment + UI are handled by Gavin's pipeline.
# ============================================================

from typing import List

TOPIC_NAME = "Insecurity & Self-Doubt (Self-esteem support)"

KEYWORDS = [
    "insecurity", "insecure", "self doubt", "self-doubt", "self esteem", "self-esteem",
    "confidence", "low confidence", "imposter syndrome", "imposter", "not good enough", "not enough",
    "compare myself", "comparison", "overthinking", "validation", "fear of judgment", "judged",
]

def get_fallback_context() -> List[str]:
    """Short, counseling-style reminders to use if RAG provides no context."""
    return [
        "Self-doubt often gets louder when you're stressed, tired, or comparing yourself to others.",
        "A harsh thought isn’t always a fact. Try naming it: 'I’m having the thought that…'",
        "Small wins count. Progress is often quiet and easy to miss.",
        "Confidence often comes after action, not before it.",
        "Try a 10-minute step: pick one tiny task and finish it, even imperfectly.",
        "If you keep seeking validation, try self-validation: 'What would I say to a friend in my spot?'",
    ]

def build_prompt(user_text: str, history_text: str, context_chunks: List[str]) -> str:
    """
    Build and return a PROMPT STRING for Llama.

    DO NOT import streamlit here.
    DO NOT call the Llama model here.
    DO NOT implement RAG here.
    DO NOT implement entailment here.
    """

    context_to_use = context_chunks[:2] if context_chunks else get_fallback_context()[:2]
    context_str = "\n".join(context_to_use)

    return f"""
You are a supportive AI companion focused on {TOPIC_NAME}.

IMPORTANT:
- You are not a doctor and you do not diagnose.
- If the user expresses immediate danger or intent to harm themselves, encourage them to seek urgent help from a trusted person nearby and local emergency/professional support.

Style guidelines:
1) If the user is caught in COMPARISON: validate it, then refocus on personal progress and what they can control today.
2) If the user uses HARSH SELF-TALK (“I’m not good enough”): gently challenge it with a balanced, believable reframe.
3) If the user fears JUDGMENT / PERFECTIONISM: encourage a small “safe” step and focus on learning over proving worth.
4) Keep the response concise (about 4–7 sentences).
5) Ask ONE gentle follow-up question.
6) Be empathetic and non-judgmental.

Helpful micro-tools (choose 1–2 only):
- “I’m having the thought that…” (creates distance from the thought)
- 10-minute action step (tiny task, imperfect is okay)
- 1-for / 1-against evidence check
- 3 small wins from the last week

Retrieved supportive context:
{context_str}

Conversation so far:
{history_text}

User message:
{user_text}

Write the best response:
""".strip()
