
# topics/loneliness.py
from __future__ import annotations
import re

TOPIC_NAME = "Loneliness and Social Isolation"
KEYWORDS = ["lonely", "alone", "isolated", "left out", "excluded", "ignored",
    "friendship", "best friend", "drifting apart", "conflict", "argument",
    "social anxiety", "awkward", "no friends", "belonging", "disconnect"]

_CLOSING_PATTERNS = [
    r"\bthank(s| you)\b",
    r"\bappreciate (it|you)\b",
    r"\bthat (helped|helps)\b",
    r"\bi (feel|am feeling) better\b",
    r"\bok(ay)?\b",
    r"\bgot it\b",
    r"\bthat makes sense\b",
    r"\bno more questions\b",
    r"\bthat's all\b",
    r"\ball good\b",
    r"\bi'm good\b",
]

def _is_closing(user_text: str) -> bool:
    t = (user_text or "").lower().strip()
    return any(re.search(p, t) for p in _CLOSING_PATTERNS)

def build_prompt(user_text: str, history_text: str, context_chunks: list[str]) -> str:
    directive = "CLOSE_NOW" if _is_closing(user_text) else "ASK_ONE"

    if context_chunks:
        formatted_chunks = "\n".join([f"[C{i+1}] {c}" for i, c in enumerate(context_chunks)])
        chunks_note = (
            "Retrieved context contains general patterns related to loneliness. "
            "Use it as reference patterns, NOT as facts about the user."
        )
    else:
        formatted_chunks = "(none)"
        chunks_note = "No retrieved context was found. Rely on the user's message."

    if directive == "CLOSE_NOW":
        ending_rule = (
            "- The user appears to be closing the conversation.\n"
            "- Do NOT ask any follow-up question.\n"
            "- End with a short supportive closing line."
        )
    else:
        ending_rule = (
            "- Ask exactly ONE gentle follow-up question at the end.\n"
            "- The question must be easy to answer in one sentence."
        )

    return f"""
You are a supportive AI companion focused on {TOPIC_NAME}.

Style guidelines:
- Warm, empathetic, non-judgmental.
- Practical, realistic small steps.
- Concise: ~90–150 words.
- Avoid medical/diagnostic claims.

Grounding rule:
{chunks_note}
- Use Retrieved context to guide examples and structure.
- Refer to context as “often/common patterns” instead of claiming it is the user's exact situation.
- If the Retrieved context is not relevant, say “NEED_MORE_CONTEXT” and ask one clarifying question.

Response structure:
1) Validation (1–2 lines)
2) Pattern insight (1 line: “Often people feel this when…”)
3) Two small actionable steps (bullet points)
4) Keep the tone natural and conversational (not like a template)
5) Ending rule:
{ending_rule}

Conversation so far:
{history_text}

Retrieved context:
{formatted_chunks}

User message:
{user_text}

Write the best response now.
""".strip()
